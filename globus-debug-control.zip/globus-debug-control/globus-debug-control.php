<?php
/**
 * Plugin Name: GLOBUS Debug Control
 * Plugin URI: https://globus.studio
 * Description: Full WordPress debug mode control: error type filtering, display and logging management, php-error body class removal.
 * Version: 2.2.4
 * Author: Yevhen Leonidov
 * Author URI: https://leonidov.dev
 * Requires at least: 5.2
 * Tested up to: 6.9
 * Requires PHP: 7.4
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: globus-debug-control
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Globus_Debug_Control {
	
	private const OPT     = 'globus_debug_control_options';
	private const VERSION = '2.2.4';
	private const MU_FILE = 'gdc-early-loader.php';
	
	private static $instance = null;
	
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	
	private function __clone() {}
	public function __wakeup() {}
	
	private function __construct() {
		$this->early_init();
		
		add_action( 'plugins_loaded', [ $this, 'plugins_loaded' ], 1 );
		add_action( 'wp_loaded', [ $this, 'on_wp_loaded' ], PHP_INT_MAX );
		add_action( 'admin_init', [ $this, 'register_settings' ] );
		add_action( 'admin_menu', [ $this, 'add_settings_page' ] );
		add_action( 'after_setup_theme', [ $this, 'early_body_class_filter' ], 1 );
		add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue_php_error_assets' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'frontend_enqueue_php_error_assets' ] );
		
		add_filter( 'body_class', [ $this, 'filter_body_class' ], PHP_INT_MAX );
		add_filter( 'admin_body_class', [ $this, 'filter_admin_body_class' ], PHP_INT_MAX );
		// Effective only as mu-plugin; as regular plugin wp_debug_mode() has already executed.
		add_filter( 'enable_wp_debug_mode_checks', '__return_false', 999 );
		
		register_deactivation_hook( __FILE__, [ $this, 'on_deactivation' ] );
		
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), [ $this, 'plugin_action_links' ] );
	}
	
	public function plugin_action_links( array $links ): array {
		$settings_link = '<a href="' . esc_url( admin_url( 'options-general.php?page=globus-debug-control' ) ) . '">' . esc_html__( 'Settings', 'globus-debug-control' ) . '</a>';
		array_unshift( $links, $settings_link );
		return $links;
	}
	
	public function early_body_class_filter() {
		remove_filter( 'body_class', [ $this, 'filter_body_class' ], PHP_INT_MAX );
		remove_filter( 'admin_body_class', [ $this, 'filter_admin_body_class' ], PHP_INT_MAX );
		add_filter( 'body_class', [ $this, 'filter_body_class' ], PHP_INT_MAX );
		add_filter( 'admin_body_class', [ $this, 'filter_admin_body_class' ], PHP_INT_MAX );
	}
	
	private function early_init() {
		$opts = $this->get_options();
		
		if ( empty( $opts['enabled'] ) ) {
			return;
		}
		
		$this->apply_error_reporting( $opts );
		$this->apply_display_settings( $opts );
		$this->apply_log_settings( $opts );
	}
	
	public function plugins_loaded() {
		$opts = $this->get_options();
		
		if ( empty( $opts['enabled'] ) ) {
			return;
		}
		
		$this->apply_error_reporting( $opts );
		$this->apply_display_settings( $opts );
		$this->apply_log_settings( $opts );
	}
	
	public function on_wp_loaded() {
		$opts = $this->get_options();
		
		if ( empty( $opts['enabled'] ) ) {
			return;
		}
		
		// Re-apply in case other plugins/themes overrode error_reporting.
		$this->apply_error_reporting( $opts );
		$this->install_error_handler( $opts );
	}
	
	private function defaults(): array {
		return [
			'enabled'                    => 1,
			'suppress_notices'           => 1,
			'suppress_deprecated'        => 1,
			'suppress_warnings'          => 0,
			'suppress_strict'            => 1,
			'display_errors_mode'        => 'inherit',
			'log_enabled'                => 1,
			'log_path'                   => '',
			'log_max_size_mb'            => 10,
			'remove_php_error_bodyclass' => 1,
			'force_in_api_contexts'      => 0,
			'install_mu_dropin'          => 0,
		];
	}
	
	public function get_options( bool $force_refresh = false ): array {
		static $cached_options = null;
		
		if ( null !== $cached_options && ! $force_refresh ) {
			return $cached_options;
		}
		
		$saved = get_option( self::OPT, null );
		
		// Migrate from legacy option key 'gdc_options'.
		if ( null === $saved ) {
			$legacy = get_option( 'gdc_options', null );
			if ( is_array( $legacy ) ) {
				update_option( self::OPT, $legacy );
				delete_option( 'gdc_options' );
				$saved = $legacy;
			} else {
				$saved = [];
			}
		}
		
		$opts = wp_parse_args( $saved, $this->defaults() );
		
		$bool_keys = [
			'enabled',
			'suppress_notices',
			'suppress_deprecated',
			'suppress_warnings',
			'suppress_strict',
			'log_enabled',
			'remove_php_error_bodyclass',
			'force_in_api_contexts',
			'install_mu_dropin',
		];
		
		foreach ( $bool_keys as $key ) {
			$opts[ $key ] = (int) ! empty( $opts[ $key ] );
		}
		
		$allowed_modes = [ 'inherit', 'on', 'off' ];
		if ( ! in_array( $opts['display_errors_mode'], $allowed_modes, true ) ) {
			$opts['display_errors_mode'] = 'inherit';
		}
		
		$opts['log_max_size_mb'] = max( 1, min( 100, (int) $opts['log_max_size_mb'] ) );
		$opts['log_path']        = trim( $opts['log_path'] );
		
		$cached_options = $opts;
		return $opts;
	}
	
	private function build_suppress_mask( array $opts ): int {
		$mask = 0;
		
		if ( $opts['suppress_deprecated'] ) {
			$mask |= E_DEPRECATED | E_USER_DEPRECATED;
		}
		
		if ( $opts['suppress_notices'] ) {
			$mask |= E_NOTICE | E_USER_NOTICE;
		}
		
		if ( $opts['suppress_warnings'] ) {
			$mask |= E_WARNING | E_USER_WARNING;
		}
		
		if ( $opts['suppress_strict'] && version_compare( PHP_VERSION, '8.0.0', '<' ) && defined( 'E_STRICT' ) ) {
			$mask |= E_STRICT;
		}
		
		return $mask;
	}
	
	private function apply_error_reporting( array $opts ) {
		if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) {
			return;
		}
		
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.prevent_path_disclosure_error_reporting -- Core debug control functionality.
		error_reporting( E_ALL & ~$this->build_suppress_mask( $opts ) );
	}
	
	private function install_error_handler( array $opts ) {
		if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) {
			return;
		}
		
		$suppress_mask = $this->build_suppress_mask( $opts );
		
		if ( 0 === $suppress_mask ) {
			return;
		}
		
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_set_error_handler -- Core debug control functionality.
		$previous = set_error_handler( function( $errno, $errstr, $errfile, $errline ) use ( $suppress_mask, &$previous ) {
			if ( $errno & $suppress_mask ) {
				return true;
			}
			
			if ( is_callable( $previous ) ) {
				return call_user_func( $previous, $errno, $errstr, $errfile, $errline );
			}
			
			return false;
		} );
	}
	
	private function apply_display_settings( array $opts ) {
		$is_api_context = $this->is_api_context();
		
		$display = '0';
		
		if ( $is_api_context && empty( $opts['force_in_api_contexts'] ) ) {
			$display = '0';
		} else {
			if ( 'on' === $opts['display_errors_mode'] ) {
				$display = '1';
			} elseif ( 'off' === $opts['display_errors_mode'] ) {
				$display = '0';
			} else {
				$display = ( defined( 'WP_DEBUG_DISPLAY' ) && WP_DEBUG_DISPLAY ) ? '1' : '0';
			}
		}
		
		// phpcs:ignore Squiz.PHP.DiscouragedFunctions.Discouraged -- Required for debug display control.
		ini_set( 'display_errors', $display );
		// phpcs:ignore Squiz.PHP.DiscouragedFunctions.Discouraged -- Required for debug display control.
		ini_set( 'display_startup_errors', $display );
	}
	
	private function apply_log_settings( array $opts ) {
		if ( empty( $opts['log_enabled'] ) ) {
			ini_set( 'log_errors', '0' ); // phpcs:ignore Squiz.PHP.DiscouragedFunctions.Discouraged -- Required for log control.
			return;
		}
		
		$log_path = $this->resolve_log_path( $opts );
		
		if ( empty( $log_path ) ) {
			$log_path = WP_CONTENT_DIR . '/debug.log';
		}
		
		$this->rotate_log_if_needed( $log_path, $opts['log_max_size_mb'] );
		
		if ( $this->ensure_log_writable( $log_path ) ) {
			ini_set( 'log_errors', '1' ); // phpcs:ignore Squiz.PHP.DiscouragedFunctions.Discouraged -- Required for log control.
			ini_set( 'error_log', $log_path ); // phpcs:ignore Squiz.PHP.DiscouragedFunctions.Discouraged -- Required for log control.
		}
	}
	
	private function resolve_log_path( array $opts ): string {
		if ( ! empty( $opts['log_path'] ) ) {
			$path = $opts['log_path'];
			
			if ( ! $this->is_absolute_path( $path ) ) {
				$path = WP_CONTENT_DIR . '/' . ltrim( $path, '/' );
			}
			
			return $this->sanitize_path( $path );
		}
		
		if ( defined( 'WP_DEBUG_LOG' ) ) {
			if ( true === WP_DEBUG_LOG || 1 === WP_DEBUG_LOG ) {
				return WP_CONTENT_DIR . '/debug.log';
			}
			
			if ( is_string( WP_DEBUG_LOG ) && '' !== WP_DEBUG_LOG ) {
				$path = WP_DEBUG_LOG;
				
				if ( ! $this->is_absolute_path( $path ) ) {
					$path = WP_CONTENT_DIR . '/' . ltrim( $path, '/' );
				}
				
				return $this->sanitize_path( $path );
			}
		}
		
		return '';
	}
	
	private function is_absolute_path( string $path ): bool {
		return ( isset( $path[0] ) && '/' === $path[0] ) || preg_match( '/^[a-zA-Z]:[\\\\\/]/', $path );
	}
	
	private function sanitize_path( string $path ): string {
		$path = str_replace( [ "\0", "\r", "\n" ], '', $path );
		$path = str_replace( '\\', '/', $path );
		return preg_replace( '#/+#', '/', $path );
	}
	
	private function ensure_log_writable( string $log_path ): bool {
		$dir = dirname( $log_path );
		
		if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
			return false;
		}
		
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable -- Low-level check before WP_Filesystem is available.
		if ( ! is_writable( $dir ) ) {
			return false;
		}
		
		if ( ! file_exists( $log_path ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- Low-level log file creation before WP_Filesystem is available.
			$handle = @fopen( $log_path, 'a' );
			if ( false === $handle ) {
				return false;
			}
			fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
			@chmod( $log_path, 0644 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_chmod
		}
		
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable -- Low-level check before WP_Filesystem is available.
		return is_writable( $log_path );
	}
	
	private function rotate_log_if_needed( string $log_path, int $max_size_mb ) {
		if ( ! file_exists( $log_path ) ) {
			return;
		}
		
		$size_bytes = @filesize( $log_path );
		
		if ( false === $size_bytes ) {
			return;
		}
		
		$max_bytes = $max_size_mb * 1024 * 1024;
		
		if ( $size_bytes > $max_bytes ) {
			$backup = $log_path . '.' . gmdate( 'Y-m-d_H-i-s' ) . '.old';
			// phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename -- Low-level log rotation before WP_Filesystem is available.
			@rename( $log_path, $backup );
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_touch
			@touch( $log_path );
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_chmod
			@chmod( $log_path, 0644 );
		}
	}
	
	private function is_api_context(): bool {
		if ( ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) ||
		     ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ||
		     ( defined( 'MS_FILES_REQUEST' ) && MS_FILES_REQUEST ) ||
		     ( defined( 'WP_INSTALLING' ) && WP_INSTALLING ) ||
		     ( defined( 'DOING_CRON' ) && DOING_CRON ) ||
		     ( defined( 'WP_CLI' ) && WP_CLI ) ||
		     ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) ||
		     ( function_exists( 'wp_is_json_request' ) && wp_is_json_request() ) ||
		     // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Read-only context detection, not form processing.
		     ( isset( $_POST['action'] ) && is_string( $_POST['action'] ) && 'heartbeat' === sanitize_text_field( wp_unslash( $_POST['action'] ) ) ) ) {
			return true;
		}
		
		return false;
	}
	
	// ── MU-Plugin Dropin ───────────────────────────────────────────────────────
	
	private function get_mu_plugin_path(): string {
		$dir = defined( 'WPMU_PLUGIN_DIR' ) ? WPMU_PLUGIN_DIR : ( WP_CONTENT_DIR . '/mu-plugins' );
		return $dir . '/' . self::MU_FILE;
	}
	
	public function is_mu_dropin_installed(): bool {
		$path = $this->get_mu_plugin_path();
		if ( ! file_exists( $path ) ) {
			return false;
		}
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Reading mu-plugin file to verify ownership.
		$content = @file_get_contents( $path );
		return false !== $content && false !== strpos( $content, 'GLOBUS Debug Control' );
	}
	
	private function generate_mu_content(): string {
		$lines = array(
			'<?php',
			'/**',
			' * GLOBUS Debug Control — Early Loader (mu-plugin)',
			' *',
			' * Sets error_reporting BEFORE regular plugins are loaded,',
			' * intercepting compile-time errors (E_DEPRECATED, E_NOTICE, etc.)',
			' * from third-party plugins loaded earlier in alphabetical order.',
			' *',
			' * Auto-generated by GLOBUS Debug Control v' . self::VERSION . '. Do not edit manually.',
			' */',
			'if ( ! defined( \'ABSPATH\' ) ) { exit; }',
			'',
			'$gdc_opts = get_option( \'globus_debug_control_options\', [] );',
			'',
			'// Migrate from legacy option key.',
			'if ( empty( $gdc_opts ) ) {',
			"\t" . '$gdc_legacy = get_option( \'gdc_options\', [] );',
			"\t" . 'if ( ! empty( $gdc_legacy ) ) {',
			"\t\t" . 'update_option( \'globus_debug_control_options\', $gdc_legacy );',
			"\t\t" . 'delete_option( \'gdc_options\' );',
			"\t\t" . '$gdc_opts = $gdc_legacy;',
			"\t" . '}',
			'}',
			'',
			'if ( empty( $gdc_opts ) || empty( $gdc_opts[\'enabled\'] ) ) {',
			"\treturn;",
			'}',
			'',
			'$gdc_mask = 0;',
			'',
			'if ( ! empty( $gdc_opts[\'suppress_deprecated\'] ) ) {',
			"\t" . '$gdc_mask |= E_DEPRECATED | E_USER_DEPRECATED;',
			'}',
			'if ( ! empty( $gdc_opts[\'suppress_notices\'] ) ) {',
			"\t" . '$gdc_mask |= E_NOTICE | E_USER_NOTICE;',
			'}',
			'if ( ! empty( $gdc_opts[\'suppress_warnings\'] ) ) {',
			"\t" . '$gdc_mask |= E_WARNING | E_USER_WARNING;',
			'}',
			'if ( ! empty( $gdc_opts[\'suppress_strict\'] ) && version_compare( PHP_VERSION, \'8.0.0\', \'<\' ) && defined( \'E_STRICT\' ) ) {',
			"\t" . '$gdc_mask |= E_STRICT;',
			'}',
			'',
			'if ( $gdc_mask > 0 ) {',
			"\t" . 'error_reporting( E_ALL & ~$gdc_mask );',
			'}',
			'',
			'// Prevent wp_debug_mode() from overriding our settings if called again.',
			'add_filter( \'enable_wp_debug_mode_checks\', \'__return_false\', 1 );',
		);
		return implode( "\n", $lines ) . "\n";
	}
	
	public function install_mu_dropin(): bool {
		$path = $this->get_mu_plugin_path();
		$dir  = dirname( $path );
		
		if ( file_exists( $path ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Reading mu-plugin file to verify ownership.
			$existing = @file_get_contents( $path );
			if ( false !== $existing && false === strpos( $existing, 'GLOBUS Debug Control' ) ) {
				return false;
			}
		}
		
		if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
			return false;
		}
		
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Writing mu-plugin file before WP_Filesystem is available.
		$result = @file_put_contents( $path, $this->generate_mu_content() );
		if ( false !== $result ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_chmod
			@chmod( $path, 0644 );
			return true;
		}
		return false;
	}
	
	public function remove_mu_dropin(): bool {
		$path = $this->get_mu_plugin_path();
		if ( ! file_exists( $path ) ) {
			return true;
		}
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Reading mu-plugin file to verify ownership before deletion.
		$content = @file_get_contents( $path );
		if ( false !== $content && false !== strpos( $content, 'GLOBUS Debug Control' ) ) {
			wp_delete_file( $path );
			return ! file_exists( $path );
		}
		return false;
	}
	
	public function on_deactivation() {
		$this->remove_mu_dropin();
	}
	
	public function register_settings() {
		register_setting( 'globus_debug_control', self::OPT, [
			'type'              => 'array',
			'sanitize_callback' => [ $this, 'sanitize_options' ],
		] );
		
		add_settings_section( 'gdc_main', __( 'General Settings', 'globus-debug-control' ), '__return_false', 'globus_debug_control' );
		
		add_settings_field( 'enabled', __( 'Enable Plugin', 'globus-debug-control' ), [ $this, 'field_enabled' ], 'globus_debug_control', 'gdc_main' );
		add_settings_field( 'suppress', __( 'Error Type Filtering', 'globus-debug-control' ), [ $this, 'field_suppress' ], 'globus_debug_control', 'gdc_main' );
		add_settings_field( 'display_errors_mode', __( 'display_errors Mode', 'globus-debug-control' ), [ $this, 'field_display_mode' ], 'globus_debug_control', 'gdc_main' );
		add_settings_field( 'logging', __( 'Logging Settings', 'globus-debug-control' ), [ $this, 'field_logging' ], 'globus_debug_control', 'gdc_main' );
		add_settings_field( 'remove_php_error_bodyclass', __( 'php-error Class', 'globus-debug-control' ), [ $this, 'field_body_class' ], 'globus_debug_control', 'gdc_main' );
		add_settings_field( 'force_in_api_contexts', __( 'API Contexts', 'globus-debug-control' ), [ $this, 'field_api_contexts' ], 'globus_debug_control', 'gdc_main' );
		add_settings_field( 'install_mu_dropin', __( 'Early Error Interception', 'globus-debug-control' ), [ $this, 'field_mu_dropin' ], 'globus_debug_control', 'gdc_main' );
	}
	
	public function sanitize_options( $input ): array {
		$output = $this->defaults();
		
		if ( ! is_array( $input ) ) {
			return $output;
		}
		
		$bool_fields = [
			'enabled', 'suppress_notices', 'suppress_deprecated', 'suppress_warnings',
			'suppress_strict', 'log_enabled', 'remove_php_error_bodyclass', 'force_in_api_contexts',
			'install_mu_dropin',
		];
		
		foreach ( $bool_fields as $field ) {
			$output[ $field ] = isset( $input[ $field ] ) ? 1 : 0;
		}
		
		if ( isset( $input['display_errors_mode'] ) ) {
			$mode = sanitize_text_field( wp_unslash( $input['display_errors_mode'] ) );
			if ( in_array( $mode, [ 'inherit', 'on', 'off' ], true ) ) {
				$output['display_errors_mode'] = $mode;
			}
		}
		
		if ( isset( $input['log_path'] ) ) {
			$output['log_path'] = sanitize_text_field( wp_unslash( $input['log_path'] ) );
		}
		
		if ( isset( $input['log_max_size_mb'] ) ) {
			$output['log_max_size_mb'] = max( 1, min( 100, (int) $input['log_max_size_mb'] ) );
		}
		
		if ( $output['install_mu_dropin'] ) {
			$this->install_mu_dropin();
		} else {
			$this->remove_mu_dropin();
		}
		
		return $output;
	}
	
	public function field_enabled() {
		$opts = $this->get_options();
		?>
		<label>
			<input type="checkbox" name="<?php echo esc_attr( self::OPT ); ?>[enabled]" value="1" <?php checked( $opts['enabled'], 1 ); ?>>
			<strong><?php esc_html_e( 'Enable debug control', 'globus-debug-control' ); ?></strong>
		</label>
		<p class="description"><?php esc_html_e( 'When disabled, the plugin does not affect PHP or WordPress settings.', 'globus-debug-control' ); ?></p>
		<?php
	}
	
	public function field_suppress() {
		$opts   = $this->get_options();
		$is_php8 = version_compare( PHP_VERSION, '8.0.0', '>=' );
		?>
		<fieldset>
			<label>
				<input type="checkbox" name="<?php echo esc_attr( self::OPT ); ?>[suppress_notices]" value="1" <?php checked( $opts['suppress_notices'], 1 ); ?>>
				<strong><?php esc_html_e( 'Suppress E_NOTICE', 'globus-debug-control' ); ?></strong> <?php esc_html_e( 'and E_USER_NOTICE', 'globus-debug-control' ); ?>
			</label><br>
			<label>
				<input type="checkbox" name="<?php echo esc_attr( self::OPT ); ?>[suppress_deprecated]" value="1" <?php checked( $opts['suppress_deprecated'], 1 ); ?>>
				<strong><?php esc_html_e( 'Suppress E_DEPRECATED', 'globus-debug-control' ); ?></strong> <?php esc_html_e( 'and E_USER_DEPRECATED', 'globus-debug-control' ); ?>
			</label><br>
			<label>
				<input type="checkbox" name="<?php echo esc_attr( self::OPT ); ?>[suppress_warnings]" value="1" <?php checked( $opts['suppress_warnings'], 1 ); ?>>
				<strong><?php esc_html_e( 'Suppress E_WARNING', 'globus-debug-control' ); ?></strong> <?php esc_html_e( 'and E_USER_WARNING (use with caution!)', 'globus-debug-control' ); ?>
			</label><br>
			<?php if ( ! $is_php8 ) : ?>
			<label>
				<input type="checkbox" name="<?php echo esc_attr( self::OPT ); ?>[suppress_strict]" value="1" <?php checked( $opts['suppress_strict'], 1 ); ?>>
				<strong><?php esc_html_e( 'Suppress E_STRICT', 'globus-debug-control' ); ?></strong>
			</label>
			<?php else : ?>
			<label style="opacity: 0.5; cursor: not-allowed;">
				<input type="checkbox" disabled>
				<strong><?php esc_html_e( 'Suppress E_STRICT', 'globus-debug-control' ); ?></strong> <em><?php esc_html_e( '(not available in PHP 8.0+)', 'globus-debug-control' ); ?></em>
			</label>
			<?php endif; ?>
		</fieldset>
		<p class="description"><?php esc_html_e( 'Selected error types will not be displayed or logged. Fatal errors (E_ERROR) are always visible.', 'globus-debug-control' ); ?></p>
		<?php
	}
	
	public function field_display_mode() {
		$opts = $this->get_options();
		?>
		<select name="<?php echo esc_attr( self::OPT ); ?>[display_errors_mode]">
			<option value="inherit" <?php selected( $opts['display_errors_mode'], 'inherit' ); ?>><?php esc_html_e( 'Inherit from WP_DEBUG_DISPLAY', 'globus-debug-control' ); ?></option>
			<option value="on" <?php selected( $opts['display_errors_mode'], 'on' ); ?>><?php esc_html_e( 'Always on', 'globus-debug-control' ); ?></option>
			<option value="off" <?php selected( $opts['display_errors_mode'], 'off' ); ?>><?php esc_html_e( 'Always off', 'globus-debug-control' ); ?></option>
		</select>
		<p class="description"><?php esc_html_e( 'Controls error output on screen. In API contexts, display is automatically disabled.', 'globus-debug-control' ); ?></p>
		<?php
	}
	
	public function field_logging() {
		$opts = $this->get_options();
		?>
		<fieldset>
			<label>
				<input type="checkbox" name="<?php echo esc_attr( self::OPT ); ?>[log_enabled]" value="1" <?php checked( $opts['log_enabled'], 1 ); ?>>
				<strong><?php esc_html_e( 'Enable error logging', 'globus-debug-control' ); ?></strong>
			</label><br><br>
			
			<label for="gdc_log_path"><?php esc_html_e( 'Log file path:', 'globus-debug-control' ); ?></label><br>
			<input type="text" id="gdc_log_path" class="regular-text code" name="<?php echo esc_attr( self::OPT ); ?>[log_path]" value="<?php echo esc_attr( $opts['log_path'] ); ?>" placeholder="<?php esc_attr_e( 'Leave empty for auto-detection', 'globus-debug-control' ); ?>">
			<p class="description"><?php esc_html_e( 'If empty: uses WP_DEBUG_LOG (usually wp-content/debug.log).', 'globus-debug-control' ); ?><br><?php esc_html_e( 'You can specify an absolute or relative (from wp-content) path.', 'globus-debug-control' ); ?></p>
			
			<label for="gdc_log_max_size"><?php esc_html_e( 'Maximum log size (MB):', 'globus-debug-control' ); ?></label><br>
			<input type="number" id="gdc_log_max_size" name="<?php echo esc_attr( self::OPT ); ?>[log_max_size_mb]" value="<?php echo esc_attr( $opts['log_max_size_mb'] ); ?>" min="1" max="100" style="width: 80px;">
			<p class="description"><?php esc_html_e( 'When exceeded, the file will be renamed with a date suffix and a new one created. Range: 1-100 MB.', 'globus-debug-control' ); ?></p>
		</fieldset>
		<?php
	}
	
	public function field_body_class() {
		$opts = $this->get_options();
		?>
		<label>
			<input type="checkbox" name="<?php echo esc_attr( self::OPT ); ?>[remove_php_error_bodyclass]" value="1" <?php checked( $opts['remove_php_error_bodyclass'], 1 ); ?>>
			<strong><?php
				$gdc_body_text = sprintf(
					/* translators: 1: CSS class name, 2: HTML tag name */
					__( 'Remove %1$s class from %2$s', 'globus-debug-control' ),
					'<code>php-error</code>',
					'<code>&lt;body&gt;</code>'
				);
				echo wp_kses( $gdc_body_text, array( 'code' => array() ) );
			?></strong>
		</label>
		<p class="description"><?php esc_html_e( 'WordPress adds this class when errors are detected. It can interfere with styling.', 'globus-debug-control' ); ?></p>
		<?php
	}
	
	public function field_api_contexts() {
		$opts = $this->get_options();
		?>
		<label>
			<input type="checkbox" name="<?php echo esc_attr( self::OPT ); ?>[force_in_api_contexts]" value="1" <?php checked( $opts['force_in_api_contexts'], 1 ); ?>>
			<strong><?php esc_html_e( 'Show errors in API contexts', 'globus-debug-control' ); ?></strong>
		</label>
		<p class="description"><?php esc_html_e( 'By default, error display is disabled in AJAX, REST API, Cron, and CLI for proper operation.', 'globus-debug-control' ); ?><br><?php esc_html_e( 'Enable only for API debugging.', 'globus-debug-control' ); ?></p>
		<?php
	}
	
	public function field_mu_dropin() {
		$opts      = $this->get_options();
		$installed = $this->is_mu_dropin_installed();
		?>
		<label>
			<input type="checkbox" name="<?php echo esc_attr( self::OPT ); ?>[install_mu_dropin]" value="1" <?php checked( $opts['install_mu_dropin'], 1 ); ?>>
			<strong><?php esc_html_e( 'Install mu-plugin for early interception', 'globus-debug-control' ); ?></strong>
		</label>
		<?php if ( $installed ) : ?>
			<span style="color: #00a32a; margin-left: 8px;">● <?php esc_html_e( 'Installed', 'globus-debug-control' ); ?></span>
		<?php else : ?>
			<span style="color: #999; margin-left: 8px;">○ <?php esc_html_e( 'Not installed', 'globus-debug-control' ); ?></span>
		<?php endif; ?>
		<p class="description">
			<?php esc_html_e( 'WordPress loads plugins alphabetically. Errors from plugins loaded earlier (e.g. Elementor) occur before GLOBUS Debug Control initializes.', 'globus-debug-control' ); ?><br>
			<?php
			$gdc_mu_text = sprintf(
				/* translators: 1: mu-plugin filename, 2: directory path */
				__( 'The mu-plugin loads first and intercepts such errors. File: %1$s in %2$s', 'globus-debug-control' ),
				'<code>' . esc_html( self::MU_FILE ) . '</code>',
				'<code>wp-content/mu-plugins/</code>'
			);
			echo wp_kses( $gdc_mu_text, array( 'code' => array() ) );
			?>
		</p>
		<?php
	}
	
	public function add_settings_page() {
		add_options_page(
			'GLOBUS Debug Control',
			'GLOBUS Debug Control',
			'manage_options',
			'globus-debug-control',
			[ $this, 'render_settings_page' ]
		);
	}
	
	public function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		
		$opts     = $this->get_options();
		$log_path = $this->resolve_log_path( $opts );
		?>
		<div class="wrap">
			<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
			
			<form action="options.php" method="post">
				<?php
				settings_fields( 'globus_debug_control' );
				do_settings_sections( 'globus_debug_control' );
				submit_button( __( 'Save Settings', 'globus-debug-control' ) );
				?>
			</form>
			
			<hr>
			
			<h2><?php esc_html_e( 'System Information', 'globus-debug-control' ); ?></h2>
			<table class="widefat striped">
				<tr>
					<td style="width: 250px;"><strong><?php esc_html_e( 'Plugin version:', 'globus-debug-control' ); ?></strong></td>
					<td><?php echo esc_html( self::VERSION ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'PHP version:', 'globus-debug-control' ); ?></strong></td>
					<td><?php echo esc_html( PHP_VERSION ); ?></td>
				</tr>
				<tr>
					<td><strong>WP_DEBUG:</strong></td>
					<td><?php echo defined( 'WP_DEBUG' ) && WP_DEBUG ? '<span style="color: #d63638;">●</span> ' . esc_html__( 'Enabled', 'globus-debug-control' ) : '<span style="color: #999;">○</span> ' . esc_html__( 'Disabled', 'globus-debug-control' ); ?></td>
				</tr>
				<tr>
					<td><strong>WP_DEBUG_DISPLAY:</strong></td>
					<td><?php echo defined( 'WP_DEBUG_DISPLAY' ) && WP_DEBUG_DISPLAY ? '<span style="color: #d63638;">●</span> ' . esc_html__( 'Enabled', 'globus-debug-control' ) : '<span style="color: #999;">○</span> ' . esc_html__( 'Disabled', 'globus-debug-control' ); ?></td>
				</tr>
				<tr>
					<td><strong>WP_DEBUG_LOG:</strong></td>
					<td><?php echo defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ? '<span style="color: #d63638;">●</span> ' . esc_html__( 'Enabled', 'globus-debug-control' ) : '<span style="color: #999;">○</span> ' . esc_html__( 'Disabled', 'globus-debug-control' ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Current error_reporting:', 'globus-debug-control' ); ?></strong></td>
					<?php // phpcs:ignore WordPress.PHP.DevelopmentFunctions.prevent_path_disclosure_error_reporting -- Admin diagnostic display. ?>
					<td><code><?php echo esc_html( error_reporting() ); ?></code></td>
				</tr>
				<tr>
					<td><strong>display_errors:</strong></td>
					<td><code><?php echo esc_html( ini_get( 'display_errors' ) ); ?></code></td>
				</tr>
				<tr>
					<td><strong>log_errors:</strong></td>
					<td><code><?php echo esc_html( ini_get( 'log_errors' ) ); ?></code></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Log file path:', 'globus-debug-control' ); ?></strong></td>
					<td>
						<?php
						if ( $log_path ) {
							echo '<code>' . esc_html( $log_path ) . '</code>';
							if ( file_exists( $log_path ) ) {
								$size = filesize( $log_path );
								echo ' <span style="color: #2271b1;">(' . esc_html__( 'size:', 'globus-debug-control' ) . ' ' . esc_html( size_format( $size ) ) . ')</span>';
							} else {
								echo ' <span style="color: #999;">(' . esc_html__( 'file does not exist', 'globus-debug-control' ) . ')</span>';
							}
						} else {
							echo '<span style="color: #999;">' . esc_html__( 'Not configured', 'globus-debug-control' ) . '</span>';
						}
						?>
					</td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Execution context:', 'globus-debug-control' ); ?></strong></td>
					<td><?php echo $this->is_api_context() ? '<span style="color: #d63638;">' . esc_html__( 'API context', 'globus-debug-control' ) . '</span>' : '<span style="color: #2271b1;">' . esc_html__( 'Normal', 'globus-debug-control' ) . '</span>'; ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'MU-plugin dropin:', 'globus-debug-control' ); ?></strong></td>
					<td><?php echo $this->is_mu_dropin_installed() ? '<span style="color: #00a32a;">●</span> ' . esc_html__( 'Installed', 'globus-debug-control' ) . ' (<code>' . esc_html( self::MU_FILE ) . '</code>)' : '<span style="color: #d63638;">●</span> ' . esc_html__( 'Not installed — early interception disabled', 'globus-debug-control' ); ?></td>
				</tr>
			</table>
			
			<p style="margin-top: 20px;"><small>© 2026 GLOBUS.studio | <?php esc_html_e( 'Version', 'globus-debug-control' ); ?> <?php echo esc_html( self::VERSION ); ?></small></p>
		</div>
		<?php
	}
	
	public function filter_body_class( array $classes ): array {
		$opts = $this->get_options();
		if ( ! empty( $opts['remove_php_error_bodyclass'] ) && ! empty( $opts['enabled'] ) ) {
			$classes = array_values( array_filter( $classes, function( $class ) {
				return 'php-error' !== $class;
			} ) );
		}
		return $classes;
	}
	
	public function filter_admin_body_class( string $classes ): string {
		$opts = $this->get_options();
		if ( ! empty( $opts['remove_php_error_bodyclass'] ) && ! empty( $opts['enabled'] ) ) {
			$list = array_filter( preg_split( '/\s+/', trim( $classes ), -1, PREG_SPLIT_NO_EMPTY ), function( $class ) {
				return 'php-error' !== trim( $class );
			} );
			return implode( ' ', $list );
		}
		return $classes;
	}
	
	public function admin_enqueue_php_error_assets() {
		$opts = $this->get_options();
		if ( empty( $opts['remove_php_error_bodyclass'] ) || empty( $opts['enabled'] ) ) {
			return;
		}
		// phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion -- Inline style, no version needed.
		wp_add_inline_style( 'common', 'body.php-error{}' );
		wp_add_inline_script( 'common', $this->get_php_error_class_js() );
	}

	public function frontend_enqueue_php_error_assets() {
		$opts = $this->get_options();
		if ( empty( $opts['remove_php_error_bodyclass'] ) || empty( $opts['enabled'] ) ) {
			return;
		}
		wp_register_style( 'gdc-php-error', false, [], false ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters -- Inline-only handle.
		wp_enqueue_style( 'gdc-php-error' );
		wp_add_inline_style( 'gdc-php-error', 'body.php-error{}' );
		wp_add_inline_script( 'jquery', $this->get_php_error_class_js() );
	}

	private function get_php_error_class_js(): string {
		return '(function(){function r(){var b=document.body||document.getElementsByTagName("body")[0];if(b&&b.classList.contains("php-error")){b.classList.remove("php-error");}}r();if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",r);}window.addEventListener("load",r);if(window.MutationObserver){var o=new MutationObserver(function(m){m.forEach(function(e){if(e.type==="attributes"&&e.attributeName==="class"){r();}});});var b=document.body||document.getElementsByTagName("body")[0];if(b){o.observe(b,{attributes:true,attributeFilter:["class"]});}}var c=0,i=setInterval(function(){r();c++;if(c>=30){clearInterval(i);}},100);})();';
	}
}

Globus_Debug_Control::instance();